<?php
session_start();
include_once ('includes.php');


 ?>


<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./style.css">
	<title>Accueil_connexion</title>
</head>
<body>

<h1 class="accueil-connexion">Consultation</h1>

    
	<p> <?php

    	if(!isset($_SESSION['id'])){
    		echo "vous n'etes pas connecté";
    	header('Location: Connexion.php');
    exit;
  } ?>
    	</p>

  <ul>
    <?php

           $req = $DB->query('Select * from VISITEUR v join travailler t where v.VIS_MATRICULE= t.VIS_MATRICULE and v.VIS_MATRICULE= :Identifiant ',array('Identifiant' => $_SESSION['id']));
          $req = $req->fetch();

           if($req['TRA_ROLE']=='Admin'){
            echo '<li><a href="./inscription.php">Ajouter un Utilisateur</a></li>';
           }
     ?>
 	
 	
 	

	  <li><a href="deconnexion.php">Deconnexion</a></li>

</ul>
     
   <form id="formulaire_recherche" method="post" action="Accueil_connexion.php">

    <input type="text" name="Rechercher" placeholder="Rechercher spécialité">
    <input type="text" name="Ville" placeholder="Ville">
       
    <select name="CodePostal">
        <option></option>
        <option>35</option> 
        <option>22</option>
         
    </select>

    <button>Rechercher</button>
   </form> 
   <table width="70%" border="1" cellpadding="5" cellspacing="5">
          <tr>
              <th>Nom</th>
              <th>Specialite</th>
              <th>Ville</th>
              <th>Adresse</th>
              <th>CP</th>
              
          </tr>

<?php
if(!empty($_POST)){
    extract($_POST);

      $Recherche = htmlspecialchars(trim($_POST['Rechercher'])).'%';
      $CodeCP = htmlspecialchars(trim($_POST['CodePostal'])).'%';
      $Ville = htmlspecialchars(trim($_POST['Ville'])).'%';

        $req = $DB->query('Select * from infopraticien where SPE_LIBELLE like :Specialite  and PRA_CP like :CodePostal and PRA_VILLE like :Ville order by PRA_NOM',array('Specialite' => $Recherche,'CodePostal' => $CodeCP, 'Ville' => $Ville));
    



foreach ($req as $r) {
  echo '<tr>
                <td>'.$r["PRA_NOM"].'</td>
                <td>'.$r["SPE_LIBELLE"].'</td>
                <td>'.$r["PRA_VILLE"].'</td>
                <td>'.$r["PRA_ADRESSE"].'</td>
                <td>'.$r["PRA_CP"].'</td>
                
      </tr>';
  # code...
}

echo '</table>';
  
}
  ?>

<footer>
  
</footer>
</body>
</html>