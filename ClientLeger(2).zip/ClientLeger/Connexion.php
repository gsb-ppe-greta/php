<?php 
session_start();



include_once('includes.php');


//Si connecter , plus possible de retourner sur la page connexion.php

if(isset($_SESSION['id'])){
header('Location: Accueil_connexion.php');
		exit;
}

if(!empty($_POST)){
	extract($_POST);
	$valid = true;

	$Identifiant = htmlspecialchars(trim($Identifiant)); //Pas de caractères spéciaux ni espace
	$mdp = htmlspecialchars(trim($mdp));

	if(empty($Identifiant)){ 
		$valid = false;
		$error_pseudo = "Veuillez renseigner un identifiant";
	}

	if(empty($mdp)){
		$valid = false;
		$error_mdp = "Veuillez renseigner un mot de passe";
	}

	//charge les informations correspondant au pseudo et mdp entré
	$req = $DB->query('Select * from VISITEUR where VIS_LOGIN= :Identifiant and VIS_MDP= :Motdepasse ',array('Identifiant' => $Identifiant, 'Motdepasse'=> md5($mdp)));
	$req = $req->fetch();

	if(!$req['VIS_LOGIN']){
		$valid =false;
		$error_compt = "Votre pseudo ou mot de passe ne correspondent pas";

	}

	if($valid){

		$_SESSION['id'] = $req['VIS_MATRICULE'];
		$_SESSION['Identifiant'] = $req['VIS_LOGIN'];

		header('Location:Accueil_connexion.php');
		exit;

	}




}


?>
<!DOCTYPE html>
<html>
<head>
	<title>Connexion</title>
	<link rel="stylesheet" type="text/css" href="./style.css">
</head>
<body>

		<img src="./image/Logo-gsb.png">
	<form class="connexion_form" method="post" action="Connexion.php">
			<label>
			<span id="id_connexion">Identifiant</span><br/>
							<?php 
								if(isset($error_compt)){
									echo $error_compt."<br/>";
								}
								if(isset($error_pseudo)){
									echo $error_pseudo."<br/>";
								}

							?>

			<input type="text" name="Identifiant" placeholder="Identifiant" value="<?php if(isset($Identifiant)) echo $Identifiant ?>" maxlength="20" required="required">
			</label><br/>

			<label>
				<span>Mot de passe</span><br/>
							<?php 
								if(isset($error_mdp)){
									echo $error_mdp."<br/>";
								}

							?>
				<input type="password" name="mdp" placeholder="Mot de passe" value="<?php if(isset($mdp)) echo $mdp ?>" maxlength="20" required="required">
			</label><br/>
			<button id="connexion_bouton" name="Connexion">Connexion</button>

		

	</form>

</body>
</html>