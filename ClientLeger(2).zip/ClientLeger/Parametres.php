<?php
session_start();
include_once('includes.php');

if(!empty($_POST)){
	extract($_POST);
	$valid = true;

	$req = $DB->query('Select * from user where identifiant= :Identifiant', array('Identifiant' => $Identifiant));
	$req = $req->fetch();


	if(!$req['mdp']== $mdp){
		echo "Mot de passe incorrect";
		$valid = false;
	}

	if(!empty($newmdp)){
	$req = $DB->insert('UPDATE `user` SET `Identifiant` = $newmdp WHERE `user`.`identifiant` =  $_SESSION['Identifiant']');
		header('Location: Parametres.php');
		exit;

	}

	if($valid){

		header('Location:Parametres.php');
		exit;

	}


}



?>

<!DOCTYPE html>
<html>
<head>
	<title>Parametres</title>
</head>
		<body> <p>Parametre de
		<?php 
		echo " ".$_SESSION['Identifiant'];
		?>
		</p>
	
	<label>
				<span>Ancien Mot de passe</span><br/>
			
				<input type="password" name="mdp" placeholder="Mot de passe" value="<?php if(isset($mdp)) echo $mdp ?>" maxlength="20" required="required">
			</label><br/>

		<label>
				<span>Nouveau Mot de passe</span><br/>

				
				<input type="password" name="newmdp" placeholder="Mot de passe" value="<?php if(isset($newmdp)) echo $newmdp ?>" maxlength="20" required="required">
			</label><br/>


<label>
</body>
</html>