-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mar. 21 mai 2019 à 14:33
-- Version du serveur :  5.7.24
-- Version de PHP :  7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gsb`
--

-- --------------------------------------------------------

--
-- Structure de la table `praticien`
--

DROP TABLE IF EXISTS `praticien`;
CREATE TABLE IF NOT EXISTS `praticien` (
  `Nom` varchar(20) NOT NULL,
  `Specialite` varchar(25) NOT NULL,
  `Ville` varchar(20) NOT NULL,
  `Adresse` varchar(30) NOT NULL,
  `CP` varchar(5) NOT NULL,
  `Telephone` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `praticien`
--

INSERT INTO `praticien` (`Nom`, `Specialite`, `Ville`, `Adresse`, `CP`, `Telephone`) VALUES
('Dupont', 'Medecin', 'Saint Malo', '2 rue du cerf', '35400', '0235256545'),
('Chevalier', 'Kine', 'Rennes', '2 rue louis braille', '35000', '0222334455'),
('Boiteux', 'Ostéo', 'Combourg', '2 rue napoleon', '35800', '0258694723'),
('Marec', 'Podologue', 'Dinard', '2 allée des jonquilles', '35470', '0278986545'),
('Dupont', 'Medecin', 'Dinan', '2 rue du bois', '22500', '0241526365'),
('Pelichet', 'Medecin', 'Saint Brieuc', '2 allée des marguerittes', '22460', '0254659874'),
('Tilmond', 'Acupuncture', 'Lamballe', '3 rue des épines', '22950', '0246523469'),
('Crosnier', 'Medecin', 'Saint Brieuc', '2 rue de fougères', '22000', '0245628596');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Identifiant` varchar(255) NOT NULL,
  `AdresseMail` varchar(100) NOT NULL,
  `Motdepasse` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `Identifiant`, `AdresseMail`, `Motdepasse`) VALUES
(7, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(8, 'pouet', 'alan2808@hotmail.com', '3d09baddc21a365b7da5ae4d0aa5cb95'),
(9, 'test', 'test@hotmail.fr', '098f6bcd4621d373cade4e832627b4f6');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
