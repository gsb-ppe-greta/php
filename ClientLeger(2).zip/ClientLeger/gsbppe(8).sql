-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 27 mai 2019 à 02:45
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gsbppe`
--

-- --------------------------------------------------------

--
-- Structure de la table `activite_compl`
--

DROP TABLE IF EXISTS `activite_compl`;
CREATE TABLE IF NOT EXISTS `activite_compl` (
  `AC_NUM` smallint(6) NOT NULL AUTO_INCREMENT,
  `AC_DATE` date DEFAULT NULL,
  `AC_LIEU` varchar(50) DEFAULT NULL,
  `AC_THEME` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`AC_NUM`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `composant`
--

DROP TABLE IF EXISTS `composant`;
CREATE TABLE IF NOT EXISTS `composant` (
  `CMP_CODE` int(11) NOT NULL AUTO_INCREMENT,
  `CMP_LIBELLE` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`CMP_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `composant`
--

INSERT INTO `composant` (`CMP_CODE`, `CMP_LIBELLE`) VALUES
(1, 'povidone'),
(2, 'amidon'),
(3, 'talc'),
(4, 'mannitol'),
(5, 'terpinéol'),
(6, 'linalol'),
(7, 'citral'),
(8, 'saccharose');

-- --------------------------------------------------------

--
-- Structure de la table `concerner`
--

DROP TABLE IF EXISTS `concerner`;
CREATE TABLE IF NOT EXISTS `concerner` (
  `RAP_NUM` smallint(6) NOT NULL,
  `PRA_NUM` smallint(6) NOT NULL,
  PRIMARY KEY (`RAP_NUM`,`PRA_NUM`),
  KEY `CONCERNER_PRATICIEN0_FK` (`PRA_NUM`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `constituer`
--

DROP TABLE IF EXISTS `constituer`;
CREATE TABLE IF NOT EXISTS `constituer` (
  `CMP_CODE` int(11) NOT NULL,
  `MED_DEPOTLEGAL` int(10) NOT NULL,
  `CST_QTE` float NOT NULL,
  `CST_UNITE` char(5) DEFAULT NULL,
  PRIMARY KEY (`CMP_CODE`,`MED_DEPOTLEGAL`),
  KEY `CONSTITUER_MEDICAMENT0_FK` (`MED_DEPOTLEGAL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `departement`
--

DROP TABLE IF EXISTS `departement`;
CREATE TABLE IF NOT EXISTS `departement` (
  `DEP_CODE` int(11) NOT NULL AUTO_INCREMENT,
  `DEP_NOM` varchar(60) DEFAULT NULL,
  `DEP_CHEFVENTE` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`DEP_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `departement`
--

INSERT INTO `departement` (`DEP_CODE`, `DEP_NOM`, `DEP_CHEFVENTE`) VALUES
(1, 'Cosmetique', 'Jean'),
(2, 'Recherche et Dev', 'Michel'),
(3, 'Probyotique', 'José');

-- --------------------------------------------------------

--
-- Structure de la table `dosage`
--

DROP TABLE IF EXISTS `dosage`;
CREATE TABLE IF NOT EXISTS `dosage` (
  `DOS_CODE` smallint(6) NOT NULL AUTO_INCREMENT,
  `DOS_QUANTITE` tinyint(4) DEFAULT NULL,
  `DOS_UNITE` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`DOS_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `dosage`
--

INSERT INTO `dosage` (`DOS_CODE`, `DOS_QUANTITE`, `DOS_UNITE`) VALUES
(1, 1, 'mg'),
(2, 2, 'mg'),
(3, 3, 'mg'),
(4, 4, 'mg'),
(5, 5, 'mg'),
(6, 6, 'mg'),
(7, 7, 'mg'),
(8, 8, 'mg'),
(9, 9, 'mg'),
(10, 1, 'cg');

-- --------------------------------------------------------

--
-- Structure de la table `famille`
--

DROP TABLE IF EXISTS `famille`;
CREATE TABLE IF NOT EXISTS `famille` (
  `FAM_CODE` smallint(6) NOT NULL AUTO_INCREMENT,
  `FAM_LIBELLE` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`FAM_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `famille`
--

INSERT INTO `famille` (`FAM_CODE`, `FAM_LIBELLE`) VALUES
(1, 'Anti-inflammatoires '),
(2, 'Antalgiques'),
(3, 'Immunologie'),
(4, 'Stomatologie'),
(5, 'Toxicologie');

-- --------------------------------------------------------

--
-- Structure de la table `fichefrais`
--

DROP TABLE IF EXISTS `fichefrais`;
CREATE TABLE IF NOT EXISTS `fichefrais` (
  `FF_MOIS` tinyint(4) NOT NULL,
  `FF_NBHORSCLASSIF` tinyint(4) DEFAULT NULL,
  `FF_MONTANTHORSCLASSIF` float DEFAULT NULL,
  `VIS_MATRICULE` int(5) NOT NULL,
  PRIMARY KEY (`FF_MOIS`),
  KEY `FK_FICHE_FRAIS_VIS_MATRICULE_VISITEUR` (`VIS_MATRICULE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `formuler`
--

DROP TABLE IF EXISTS `formuler`;
CREATE TABLE IF NOT EXISTS `formuler` (
  `MED_DEPOTLEGAL` int(10) NOT NULL,
  `PRE_CODE` int(11) NOT NULL,
  PRIMARY KEY (`MED_DEPOTLEGAL`,`PRE_CODE`),
  KEY `FORMULER_PRESENTATION0_FK` (`PRE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `inclure`
--

DROP TABLE IF EXISTS `inclure`;
CREATE TABLE IF NOT EXISTS `inclure` (
  `TF_CODE` smallint(6) NOT NULL,
  `FF_MOIS` tinyint(4) NOT NULL,
  `INC_QTE` tinyint(4) NOT NULL,
  `INC_MONTANT` float NOT NULL,
  `VIS_MATRICULE` int(5) NOT NULL,
  PRIMARY KEY (`TF_CODE`,`FF_MOIS`),
  KEY `INCLURE_FICHEFRAIS0_FK` (`FF_MOIS`),
  KEY `INCLURE_TYPEFRAIS2_FK` (`VIS_MATRICULE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `infopraticien`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `infopraticien`;
CREATE TABLE IF NOT EXISTS `infopraticien` (
`PRA_NOM` varchar(25)
,`SPE_LIBELLE` varchar(75)
,`PRA_VILLE` varchar(25)
,`PRA_ADRESSE` varchar(50)
,`PRA_CP` varchar(5)
);

-- --------------------------------------------------------

--
-- Structure de la table `interagir`
--

DROP TABLE IF EXISTS `interagir`;
CREATE TABLE IF NOT EXISTS `interagir` (
  `MED_DEPOTLEGAL` int(10) NOT NULL,
  `MED_DEPOTLEGAL_MEDICAMENT` int(10) NOT NULL,
  PRIMARY KEY (`MED_DEPOTLEGAL`,`MED_DEPOTLEGAL_MEDICAMENT`),
  KEY `Interagir_MEDICAMENT0_FK` (`MED_DEPOTLEGAL_MEDICAMENT`,`MED_DEPOTLEGAL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `inviter`
--

DROP TABLE IF EXISTS `inviter`;
CREATE TABLE IF NOT EXISTS `inviter` (
  `PRA_NUM` smallint(6) NOT NULL,
  `AC_NUM` smallint(6) NOT NULL,
  `SPECIALISTEON` varchar(50) NOT NULL,
  PRIMARY KEY (`PRA_NUM`,`AC_NUM`),
  KEY `INVITER_ACTIVITE_COMPL0_FK` (`AC_NUM`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `medicament`
--

DROP TABLE IF EXISTS `medicament`;
CREATE TABLE IF NOT EXISTS `medicament` (
  `MED_DEPOTLEGAL` int(10) NOT NULL AUTO_INCREMENT,
  `MED_NOMCOMMERCIAL` varchar(25) DEFAULT NULL,
  `MED_COMPOSITION` varchar(25) DEFAULT NULL,
  `MED_EFFETS` varchar(25) DEFAULT NULL,
  `MED_CONTREINDIC` varchar(25) DEFAULT NULL,
  `MED_PRIXECHANTILLON` float DEFAULT NULL,
  PRIMARY KEY (`MED_DEPOTLEGAL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `offrir`
--

DROP TABLE IF EXISTS `offrir`;
CREATE TABLE IF NOT EXISTS `offrir` (
  `MED_DEPOTLEGAL` int(10) NOT NULL,
  `RAP_NUM` smallint(6) NOT NULL,
  `OFF_QTE` tinyint(4) NOT NULL,
  PRIMARY KEY (`MED_DEPOTLEGAL`,`RAP_NUM`),
  KEY `OFFRIR_RAPPORT_VISITE0_FK` (`RAP_NUM`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `posseder`
--

DROP TABLE IF EXISTS `posseder`;
CREATE TABLE IF NOT EXISTS `posseder` (
  `SPE_CODE` int(11) NOT NULL,
  `PRA_NUM` smallint(6) NOT NULL,
  `POS_DIPLOME` varchar(80) NOT NULL,
  `POS_COEFPRESTATION` float NOT NULL,
  PRIMARY KEY (`SPE_CODE`,`PRA_NUM`),
  KEY `POSSEDER_PRATICIEN0_FK` (`PRA_NUM`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `posseder`
--

INSERT INTO `posseder` (`SPE_CODE`, `PRA_NUM`, `POS_DIPLOME`, `POS_COEFPRESTATION`) VALUES
(1, 1, 'Université de Rennes 1', 0.8),
(2, 4, 'Université de Nantes', 0.4),
(5, 2, 'Université de Niort', 0.9);

-- --------------------------------------------------------

--
-- Structure de la table `praticien`
--

DROP TABLE IF EXISTS `praticien`;
CREATE TABLE IF NOT EXISTS `praticien` (
  `PRA_NUM` smallint(6) NOT NULL AUTO_INCREMENT,
  `PRA_NOM` varchar(25) DEFAULT NULL,
  `PRA_PRENOM` varchar(25) DEFAULT NULL,
  `PRA_ADRESSE` varchar(50) DEFAULT NULL,
  `PRA_CP` varchar(5) DEFAULT NULL,
  `PRA_VILLE` varchar(25) DEFAULT NULL,
  `PRA_COEFNOTORIETE` float DEFAULT NULL,
  `TYP_CODE` int(3) DEFAULT NULL,
  PRIMARY KEY (`PRA_NUM`),
  KEY `PRATICIEN_TYPE_PRATICIEN_FK` (`TYP_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `praticien`
--

INSERT INTO `praticien` (`PRA_NUM`, `PRA_NOM`, `PRA_PRENOM`, `PRA_ADRESSE`, `PRA_CP`, `PRA_VILLE`, `PRA_COEFNOTORIETE`, `TYP_CODE`) VALUES
(1, 'Brebel', 'Michel', '2 rue du cerf', '35400', 'Saint Malo', 0.2, 1),
(2, 'Michel', 'Bertrand', '2 rue napoléon', '22750', 'Dinan', 0.2, 2),
(3, 'White', 'Kenny', '15 rue du lion', '35650', 'Combourg', 0.5, 5),
(4, 'Martin', 'Thibault', '38 avenue de l\'hirondelle', '22310', 'Saint Brieuc', 0.85, 6);

-- --------------------------------------------------------

--
-- Structure de la table `prescrire`
--

DROP TABLE IF EXISTS `prescrire`;
CREATE TABLE IF NOT EXISTS `prescrire` (
  `MED_DEPOTLEGAL` int(10) NOT NULL,
  `TIN_CODE` tinyint(4) NOT NULL,
  `DOS_CODE` smallint(6) NOT NULL,
  `PRE_POSOLOGIE` varchar(5) NOT NULL,
  PRIMARY KEY (`MED_DEPOTLEGAL`,`TIN_CODE`,`DOS_CODE`),
  KEY `PRESCRIRE_TYPE_INDIVIDU0_FK` (`TIN_CODE`),
  KEY `PRESCRIRE_DOSAGE1_FK` (`DOS_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `presentation`
--

DROP TABLE IF EXISTS `presentation`;
CREATE TABLE IF NOT EXISTS `presentation` (
  `PRE_CODE` int(11) NOT NULL AUTO_INCREMENT,
  `PRE_LIBELLE` varchar(25) NOT NULL,
  PRIMARY KEY (`PRE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `rapport_visite`
--

DROP TABLE IF EXISTS `rapport_visite`;
CREATE TABLE IF NOT EXISTS `rapport_visite` (
  `RAP_NUM` smallint(6) NOT NULL AUTO_INCREMENT,
  `RAP_DATE` date DEFAULT NULL,
  `RAP_BILAN` text,
  `RAP_MOTIF` varchar(50) DEFAULT NULL,
  `VIS_MATRICULE` int(5) NOT NULL,
  `PRA_NUM` smallint(6) NOT NULL,
  PRIMARY KEY (`RAP_NUM`),
  KEY `FK_RAPPORT_VISITE_VIS_MATRICULE_VISITEUR` (`VIS_MATRICULE`),
  KEY `FK_RAPPORT_VISITE_PRA_NUM_PRATICIEN` (`PRA_NUM`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `rattacher`
--

DROP TABLE IF EXISTS `rattacher`;
CREATE TABLE IF NOT EXISTS `rattacher` (
  `REG_CODE` tinyint(4) NOT NULL,
  `SEC_CODE` tinyint(4) NOT NULL,
  PRIMARY KEY (`REG_CODE`,`SEC_CODE`),
  KEY `RATTACHER_SECTEUR0_FK` (`SEC_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `realiser`
--

DROP TABLE IF EXISTS `realiser`;
CREATE TABLE IF NOT EXISTS `realiser` (
  `AC_NUM` smallint(6) NOT NULL,
  `VIS_MATRICULE` int(5) NOT NULL,
  PRIMARY KEY (`AC_NUM`,`VIS_MATRICULE`),
  KEY `REALISER_VISITEUR0_FK` (`VIS_MATRICULE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `rediger`
--

DROP TABLE IF EXISTS `rediger`;
CREATE TABLE IF NOT EXISTS `rediger` (
  `RAP_NUM` smallint(6) NOT NULL,
  `VIS_MATRICULE` int(5) NOT NULL,
  PRIMARY KEY (`RAP_NUM`,`VIS_MATRICULE`),
  KEY `REDIGER_VISITEUR0_FK` (`VIS_MATRICULE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `region`
--

DROP TABLE IF EXISTS `region`;
CREATE TABLE IF NOT EXISTS `region` (
  `REG_CODE` tinyint(4) NOT NULL AUTO_INCREMENT,
  `REG_NOM` varchar(40) DEFAULT NULL,
  `SEC_CODE` varchar(30) NOT NULL,
  PRIMARY KEY (`REG_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `region`
--

INSERT INTO `region` (`REG_CODE`, `REG_NOM`, `SEC_CODE`) VALUES
(1, 'Auvergne', '2'),
(2, 'Bourgogne-Franche-Comté', '4'),
(3, 'Bretagne', '1'),
(4, 'Centre-Val de Loire', '1'),
(5, 'Corse', '4'),
(6, 'Grand Est ', '3'),
(7, 'Hauts-de-France', '3'),
(8, 'Ïle-de-France', '2'),
(9, 'Normandie', '2'),
(10, 'Nouvelle-Aquitaine', '1'),
(11, 'Occitanie', '4'),
(12, 'Pays de la Loire', '1'),
(13, 'Provence-Alpes-Côte D\'Azur', '4'),
(14, 'Guadeloupe', '5'),
(15, 'Martinique', '5'),
(16, 'Guyane', '5'),
(17, 'La Réunion', '5'),
(18, 'Mayotte', '5');

-- --------------------------------------------------------

--
-- Structure de la table `rembourser`
--

DROP TABLE IF EXISTS `rembourser`;
CREATE TABLE IF NOT EXISTS `rembourser` (
  `VIS_MATRICULE` int(5) NOT NULL,
  `FF_MOIS` tinyint(4) NOT NULL,
  PRIMARY KEY (`VIS_MATRICULE`,`FF_MOIS`),
  KEY `REMBOURSER_FICHEFRAIS0_FK` (`FF_MOIS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `secteur`
--

DROP TABLE IF EXISTS `secteur`;
CREATE TABLE IF NOT EXISTS `secteur` (
  `SEC_CODE` tinyint(4) NOT NULL AUTO_INCREMENT,
  `SEC_LIBELLE` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`SEC_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `secteur`
--

INSERT INTO `secteur` (`SEC_CODE`, `SEC_LIBELLE`) VALUES
(1, 'GRAND-OUEST'),
(2, 'CENTRE'),
(3, 'NORD-EST'),
(4, 'SUD-EST'),
(5, 'DOM TOM');

-- --------------------------------------------------------

--
-- Structure de la table `specialite`
--

DROP TABLE IF EXISTS `specialite`;
CREATE TABLE IF NOT EXISTS `specialite` (
  `SPE_CODE` int(11) NOT NULL AUTO_INCREMENT,
  `SPE_LIBELLE` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`SPE_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `specialite`
--

INSERT INTO `specialite` (`SPE_CODE`, `SPE_LIBELLE`) VALUES
(1, 'Allergologue'),
(2, 'Anesthésiste'),
(3, 'Pédiatre'),
(4, 'Hématologue'),
(5, 'Généraliste'),
(6, 'Neurologue'),
(7, 'Psychiatre'),
(8, 'Radiologue');

-- --------------------------------------------------------

--
-- Structure de la table `travailler`
--

DROP TABLE IF EXISTS `travailler`;
CREATE TABLE IF NOT EXISTS `travailler` (
  `REG_CODE` tinyint(4) NOT NULL,
  `DATE_ROLE` date NOT NULL,
  `VIS_MATRICULE` int(5) NOT NULL,
  `TRA_ROLE` varchar(30) NOT NULL,
  PRIMARY KEY (`REG_CODE`,`VIS_MATRICULE`),
  KEY `TRAVAILLER_VISITEUR0_FK` (`VIS_MATRICULE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `travailler`
--

INSERT INTO `travailler` (`REG_CODE`, `DATE_ROLE`, `VIS_MATRICULE`, `TRA_ROLE`) VALUES
(3, '2019-05-08', 1, 'Admin');

-- --------------------------------------------------------

--
-- Structure de la table `typefrais`
--

DROP TABLE IF EXISTS `typefrais`;
CREATE TABLE IF NOT EXISTS `typefrais` (
  `TF_CODE` smallint(6) NOT NULL AUTO_INCREMENT,
  `TF_LIBELLE` varchar(30) DEFAULT NULL,
  `TF_FORFAIT` float DEFAULT NULL,
  PRIMARY KEY (`TF_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `type_individu`
--

DROP TABLE IF EXISTS `type_individu`;
CREATE TABLE IF NOT EXISTS `type_individu` (
  `TIN_CODE` tinyint(4) NOT NULL AUTO_INCREMENT,
  `TIN_LIBELLE` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`TIN_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `type_individu`
--

INSERT INTO `type_individu` (`TIN_CODE`, `TIN_LIBELLE`) VALUES
(1, 'Visiteur'),
(2, 'Administrateur'),
(3, 'Commercial');

-- --------------------------------------------------------

--
-- Structure de la table `type_praticien`
--

DROP TABLE IF EXISTS `type_praticien`;
CREATE TABLE IF NOT EXISTS `type_praticien` (
  `TYP_CODE` int(3) NOT NULL AUTO_INCREMENT,
  `TYP_LIBELLE` varchar(30) DEFAULT NULL,
  `TYP_LIEU` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`TYP_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `type_praticien`
--

INSERT INTO `type_praticien` (`TYP_CODE`, `TYP_LIBELLE`, `TYP_LIEU`) VALUES
(1, 'Generaliste', 'Hopital'),
(2, 'Specialiste', 'Hopital'),
(3, 'Generaliste', 'Cabinet'),
(4, 'Specialiste', 'Cabinet'),
(5, 'Generaliste', 'Clinique'),
(6, 'Specialiste', 'Clinique');

-- --------------------------------------------------------

--
-- Structure de la table `visiteur`
--

DROP TABLE IF EXISTS `visiteur`;
CREATE TABLE IF NOT EXISTS `visiteur` (
  `VIS_MATRICULE` int(5) NOT NULL AUTO_INCREMENT,
  `VIS_NOM` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `VIS_PRENOM` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `VIS_LOGIN` varchar(15) CHARACTER SET latin1 NOT NULL,
  `VIS_MDP` varchar(150) CHARACTER SET latin1 NOT NULL,
  `VIS_ADRESSE` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `VIS_CP` varchar(5) CHARACTER SET latin1 DEFAULT NULL,
  `VIS_VILLE` varchar(25) CHARACTER SET latin1 DEFAULT NULL,
  `VIS_DATEEMBAUCHE` date DEFAULT NULL,
  `SEC_CODE` tinyint(4) DEFAULT NULL,
  `DEP_CODE` int(11) NOT NULL,
  PRIMARY KEY (`VIS_MATRICULE`),
  KEY `VISITEUR_SECTEUR_FK` (`SEC_CODE`),
  KEY `VISITEUR_DEPARTEMENT0_FK` (`DEP_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `visiteur`
--

INSERT INTO `visiteur` (`VIS_MATRICULE`, `VIS_NOM`, `VIS_PRENOM`, `VIS_LOGIN`, `VIS_MDP`, `VIS_ADRESSE`, `VIS_CP`, `VIS_VILLE`, `VIS_DATEEMBAUCHE`, `SEC_CODE`, `DEP_CODE`) VALUES
(1, 'Dubois', 'Jean', 'admin', '21232f297a57a5a743894a0e4a801fc3', '8 rue napoleon', '35400', 'Saint-Malo', '2019-05-02', 1, 2),
(2, 'Chevalier', 'Alan', 'pouet', '3d09baddc21a365b7da5ae4d0aa5cb95', 'pouet', '35400', 'Renne', '2019-05-09', 1, 1);

-- --------------------------------------------------------

--
-- Structure de la vue `infopraticien`
--
DROP TABLE IF EXISTS `infopraticien`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `infopraticien`  AS  select `pr`.`PRA_NOM` AS `PRA_NOM`,`s`.`SPE_LIBELLE` AS `SPE_LIBELLE`,`pr`.`PRA_VILLE` AS `PRA_VILLE`,`pr`.`PRA_ADRESSE` AS `PRA_ADRESSE`,`pr`.`PRA_CP` AS `PRA_CP` from ((`praticien` `pr` join `posseder` `p` on((`pr`.`PRA_NUM` = `p`.`PRA_NUM`))) join `specialite` `s` on((`s`.`SPE_CODE` = `p`.`SPE_CODE`))) where ((`pr`.`PRA_NUM` = `p`.`PRA_NUM`) and (`p`.`SPE_CODE` = `s`.`SPE_CODE`)) ;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `concerner`
--
ALTER TABLE `concerner`
  ADD CONSTRAINT `CONCERNER_PRATICIEN0_FK` FOREIGN KEY (`PRA_NUM`) REFERENCES `praticien` (`PRA_NUM`),
  ADD CONSTRAINT `CONCERNER_RAPPORT_VISITE_FK` FOREIGN KEY (`RAP_NUM`) REFERENCES `rapport_visite` (`RAP_NUM`);

--
-- Contraintes pour la table `constituer`
--
ALTER TABLE `constituer`
  ADD CONSTRAINT `CONSTITUER_COMPOSANT_FK` FOREIGN KEY (`CMP_CODE`) REFERENCES `composant` (`CMP_CODE`),
  ADD CONSTRAINT `CONSTITUER_MEDICAMENT0_FK` FOREIGN KEY (`MED_DEPOTLEGAL`) REFERENCES `medicament` (`MED_DEPOTLEGAL`);

--
-- Contraintes pour la table `fichefrais`
--
ALTER TABLE `fichefrais`
  ADD CONSTRAINT `FK_FICHE_FRAIS_VIS_MATRICULE_VISITEUR` FOREIGN KEY (`VIS_MATRICULE`) REFERENCES `visiteur` (`VIS_MATRICULE`);

--
-- Contraintes pour la table `formuler`
--
ALTER TABLE `formuler`
  ADD CONSTRAINT `FORMULER_MEDICAMENT_FK` FOREIGN KEY (`MED_DEPOTLEGAL`) REFERENCES `medicament` (`MED_DEPOTLEGAL`),
  ADD CONSTRAINT `FORMULER_PRESENTATION0_FK` FOREIGN KEY (`PRE_CODE`) REFERENCES `presentation` (`PRE_CODE`);

--
-- Contraintes pour la table `inclure`
--
ALTER TABLE `inclure`
  ADD CONSTRAINT `INCLURE_FICHEFRAIS0_FK` FOREIGN KEY (`FF_MOIS`) REFERENCES `fichefrais` (`FF_MOIS`),
  ADD CONSTRAINT `INCLURE_TYPEFRAIS2_FK` FOREIGN KEY (`VIS_MATRICULE`) REFERENCES `fichefrais` (`VIS_MATRICULE`),
  ADD CONSTRAINT `INCLURE_TYPEFRAIS_FK` FOREIGN KEY (`TF_CODE`) REFERENCES `typefrais` (`TF_CODE`);

--
-- Contraintes pour la table `interagir`
--
ALTER TABLE `interagir`
  ADD CONSTRAINT `Interagir_MEDICAMENT0_FK` FOREIGN KEY (`MED_DEPOTLEGAL_MEDICAMENT`) REFERENCES `medicament` (`MED_DEPOTLEGAL`),
  ADD CONSTRAINT `Interagir_MEDICAMENT_FK` FOREIGN KEY (`MED_DEPOTLEGAL`) REFERENCES `medicament` (`MED_DEPOTLEGAL`);

--
-- Contraintes pour la table `inviter`
--
ALTER TABLE `inviter`
  ADD CONSTRAINT `INVITER_ACTIVITE_COMPL0_FK` FOREIGN KEY (`AC_NUM`) REFERENCES `activite_compl` (`AC_NUM`),
  ADD CONSTRAINT `INVITER_PRATICIEN_FK` FOREIGN KEY (`PRA_NUM`) REFERENCES `praticien` (`PRA_NUM`);

--
-- Contraintes pour la table `offrir`
--
ALTER TABLE `offrir`
  ADD CONSTRAINT `OFFRIR_MEDICAMENT_FK` FOREIGN KEY (`MED_DEPOTLEGAL`) REFERENCES `medicament` (`MED_DEPOTLEGAL`),
  ADD CONSTRAINT `OFFRIR_RAPPORT_VISITE0_FK` FOREIGN KEY (`RAP_NUM`) REFERENCES `rapport_visite` (`RAP_NUM`);

--
-- Contraintes pour la table `posseder`
--
ALTER TABLE `posseder`
  ADD CONSTRAINT `POSSEDER_PRATICIEN0_FK` FOREIGN KEY (`PRA_NUM`) REFERENCES `praticien` (`PRA_NUM`),
  ADD CONSTRAINT `POSSEDER_SPECIALITE_FK` FOREIGN KEY (`SPE_CODE`) REFERENCES `specialite` (`SPE_CODE`);

--
-- Contraintes pour la table `praticien`
--
ALTER TABLE `praticien`
  ADD CONSTRAINT `PRATICIEN_TYPE_PRATICIEN_FK` FOREIGN KEY (`TYP_CODE`) REFERENCES `type_praticien` (`TYP_CODE`);

--
-- Contraintes pour la table `prescrire`
--
ALTER TABLE `prescrire`
  ADD CONSTRAINT `PRESCRIRE_DOSAGE1_FK` FOREIGN KEY (`DOS_CODE`) REFERENCES `dosage` (`DOS_CODE`),
  ADD CONSTRAINT `PRESCRIRE_MEDICAMENT_FK` FOREIGN KEY (`MED_DEPOTLEGAL`) REFERENCES `medicament` (`MED_DEPOTLEGAL`),
  ADD CONSTRAINT `PRESCRIRE_TYPE_INDIVIDU0_FK` FOREIGN KEY (`TIN_CODE`) REFERENCES `type_individu` (`TIN_CODE`);

--
-- Contraintes pour la table `rapport_visite`
--
ALTER TABLE `rapport_visite`
  ADD CONSTRAINT `FK_RAPPORT_VISITE_PRA_NUM_PRATICIEN` FOREIGN KEY (`PRA_NUM`) REFERENCES `praticien` (`PRA_NUM`),
  ADD CONSTRAINT `FK_RAPPORT_VISITE_VIS_MATRICULE_VISITEUR` FOREIGN KEY (`VIS_MATRICULE`) REFERENCES `visiteur` (`VIS_MATRICULE`);

--
-- Contraintes pour la table `rattacher`
--
ALTER TABLE `rattacher`
  ADD CONSTRAINT `RATTACHER_REGION_FK` FOREIGN KEY (`REG_CODE`) REFERENCES `region` (`REG_CODE`),
  ADD CONSTRAINT `RATTACHER_SECTEUR0_FK` FOREIGN KEY (`SEC_CODE`) REFERENCES `secteur` (`SEC_CODE`);

--
-- Contraintes pour la table `realiser`
--
ALTER TABLE `realiser`
  ADD CONSTRAINT `REALISER_ACTIVITE_COMPL_FK` FOREIGN KEY (`AC_NUM`) REFERENCES `activite_compl` (`AC_NUM`),
  ADD CONSTRAINT `REALISER_VISITEUR0_FK` FOREIGN KEY (`VIS_MATRICULE`) REFERENCES `visiteur` (`VIS_MATRICULE`);

--
-- Contraintes pour la table `rediger`
--
ALTER TABLE `rediger`
  ADD CONSTRAINT `REDIGER_RAPPORT_VISITE_FK` FOREIGN KEY (`RAP_NUM`) REFERENCES `rapport_visite` (`RAP_NUM`),
  ADD CONSTRAINT `REDIGER_VISITEUR0_FK` FOREIGN KEY (`VIS_MATRICULE`) REFERENCES `visiteur` (`VIS_MATRICULE`);

--
-- Contraintes pour la table `rembourser`
--
ALTER TABLE `rembourser`
  ADD CONSTRAINT `REMBOURSER_FICHEFRAIS0_FK` FOREIGN KEY (`FF_MOIS`) REFERENCES `fichefrais` (`FF_MOIS`),
  ADD CONSTRAINT `REMBOURSER_VISITEUR_FK` FOREIGN KEY (`VIS_MATRICULE`) REFERENCES `visiteur` (`VIS_MATRICULE`);

--
-- Contraintes pour la table `travailler`
--
ALTER TABLE `travailler`
  ADD CONSTRAINT `TRAVAILLER_REGION_FK` FOREIGN KEY (`REG_CODE`) REFERENCES `region` (`REG_CODE`),
  ADD CONSTRAINT `TRAVAILLER_VISITEUR0_FK` FOREIGN KEY (`VIS_MATRICULE`) REFERENCES `visiteur` (`VIS_MATRICULE`);

--
-- Contraintes pour la table `visiteur`
--
ALTER TABLE `visiteur`
  ADD CONSTRAINT `VISITEUR_DEPARTEMENT0_FK` FOREIGN KEY (`DEP_CODE`) REFERENCES `departement` (`DEP_CODE`),
  ADD CONSTRAINT `VISITEUR_SECTEUR_FK` FOREIGN KEY (`SEC_CODE`) REFERENCES `secteur` (`SEC_CODE`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
