<?php
include_once ('includes.php');
?>



<!DOCTYPE html>
<html lang="fr"><meta charset="UTF-8">
<head>
<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>GSB</title>
</head>
<body>

	<h1 class="accueil-h1">Application Consultation GSB</h1>


<img class="logo" src="./image/Logo-gsb.png">

<div class="accueil_contenaire">
	<p> 
		Bienvenue sur l'outil de consultation GSB.
	</p>

	<div class="accueil_choix">
			<br>
			<a id="accueil_connexion"  href="./Connexion.php">Connexion</a>
			
	</div>
</div>

<footer>
	
</footer>
	
</body>
</html>