<?php
session_start();

include_once ('includes.php');


//Si connecter , plus possible de retourner sur la page inscription.php


if (!empty($_POST)){
	extract($_POST);
	$valid = true;


	$Nom = htmlspecialchars(trim($Nom));
	$Prenom = htmlspecialchars(trim($Prenom));
	$Identifiant = htmlspecialchars(trim($Identifiant)); //Pas de caractères spéciaux ni espace
	$mdp = htmlspecialchars(trim($mdp));
	$ConfirmerMdp= htmlspecialchars(trim($ConfirmerMdp));
	$Adresse = htmlspecialchars(trim($Adresse));
	$CP = htmlspecialchars(trim($CP));
	$Ville = htmlspecialchars(trim($Ville));


	if(empty($Nom)){
		$valid = false;
		$error_nom = "Veuillez renseigner un Nom";
	}

	if(empty($Prenom)){
		$valid = false;
		$error_prenom = "Veuillez renseigner un Prenom";
	}


	if(empty($Identifiant)){ 
		$valid = false;
		$error_pseudo = "Veuillez renseigner un identifiant";
	}
	//verification si l'identifiant est déja use
	$req = $DB->query('Select VIS_LOGIN from visiteur where VIS_LOGIN= :Identifiant', array('Identifiant' => $Identifiant));
	$req = $req->fetch();

	if (!empty($Identifiant) && $req['VIS_LOGIN']){
		$valid =false;
		$error_pseudo = "Cet identifiant est déja pris";
	}

	if(empty($mdp)){
		$valid = false;
		$error_mdp = "Veuillez renseigner un mot de passe";
	}

	if(empty($ConfirmerMdp)){
		$valid = false;
		$error_confirmemdp = "Veuillez confirmer le mot de passe";
	}

	if(!empty($mdp) && !empty($ConfirmerMdp)){
		if($mdp != $ConfirmerMdp){
			$valid= false;
			$error_confirmemdp = "La confirmation est différente";


		}
	}
	if(empty($Adresse)){
		$valid = false;
		$error_Adresse = "Veuillez renseigner une adresse";
	}

	if(empty($CP)){
		$valid = false;
		$error_CP = "Veuillez renseigner un CodePostale";
	}
	if(empty($Ville)){
		$valid = false;
		$error_Ville = "Veuillez renseigner une Ville";
	}

	if($valid){
		$DB->insert('Insert into visiteur (VIS_NOM,VIS_PRENOM,VIS_LOGIN,VIS_MDP,VIS_ADRESSE,VIS_CP,VIS_VILLE,VIS_DATEEMBAUCHE,SEC_CODE,DEP_CODE) values (:VIS_NOM, :VIS_PRENOM, :VIS_LOGIN, :VIS_MDP, :VIS_ADRESSE, :VIS_CP, :VIS_VILLE, :VIS_DATEEMBAUCHE, :SEC_CODE, :DEP_CODE)', array ('VIS_NOM' => $Nom, 'VIS_PRENOM' => $Prenom,'VIS_LOGIN' => $Identifiant,'VIS_MDP' => md5($mdp), 'VIS_ADRESSE' => $Adresse,'VIS_CP' => $CP,'VIS_VILLE' => $Ville, 'VIS_DATEEMBAUCHE' => $Date_Embauche, 'SEC_CODE' => $Code_Secteur,'DEP_CODE' => $Code_dep));
		header('Location: Connexion.php');
		exit;

	}

}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="./style.css">
	<title>Inscription</title>
</head>
<body>
	<h1 id="inscription_titre">Ajouter un Utilisateur</h1>
	<form class="inscription_form" method="post" action="inscription.php">

		<label>
			<span>Nom</span><br/>
			<?php 
				if(isset($error_nom)){
					echo '<span class="alerte">'.$error_nom."</span><br/>";
				}

			?>

			<input type="text" name="Nom" placeholder="Nom" value="<?php if(isset($Nom)) echo $Nom ?>" maxlength="20" required="required">
		</label><br/>

		<label>
			<span>Prenom</span><br/>
			<?php 
				if(isset($error_prenom)){
					echo '<span class="alerte">'.$error_prenom."</span><br/>";
				}

			?>

			<input type="text" name="Prenom" placeholder="Prenom" value="<?php if(isset($Prenom)) echo $Prenom ?>" maxlength="20" required="required">
		</label><br/>

		<label>
			<span>Identifiant</span><br/>
			<?php 
				if(isset($error_pseudo)){
					echo '<span class="alerte">'.$error_pseudo."</span><br/>";
				}

			?>

			<input type="text" name="Identifiant" placeholder="Identifiant" value="<?php if(isset($Identifiant)) echo $Identifiant ?>" maxlength="20" required="required">
		</label><br/>

		<label>
			<span>Mot de passe</span><br/>
			<?php 
				if(isset($error_mdp)){
					echo $error_mdp."<br/>";
				}

			?>
			<input type="password" name="mdp" placeholder="Mot de passe" value="<?php if(isset($mdp)) echo $mdp ?>" maxlength="20" required="required">
		</label><br/>

		<label>
			<span>Confirmer le Mdp</span><br/>
			<?php 
				if(isset($error_confirmemdp)){
					echo $error_confirmemdp."<br/>";
				}

			?>
			<input type="password" name="ConfirmerMdp" placeholder="Mot de passe" value="<?php if(isset($ConfirmerMdp)) echo $ConfirmerMdp ?>" maxlength="20" required="required">
		</label><br/>


		<label>
			<span>Adresse</span><br/>
			<?php 
				if(isset($error_nom)){
					echo '<span class="alerte">'.$error_nom."</span><br/>";
				}

			?>

			<input type="text" name="Adresse" placeholder="Adresse" value="<?php if(isset($Adresse)) echo $Adresse ?>" maxlength="20" required="required">
		</label><br/>

		<label>
			<span>CP</span><br/>
			<?php 
				if(isset($error_CP)){
					echo '<span class="alerte">'.$error_CP."</span><br/>";
				}

			?>

			<input type="text" name="CP" placeholder="CodePostale" value="<?php if(isset($CP)) echo $CP ?>" maxlength="5" required="required">
		</label><br/>
		<label>
			<span>Ville</span><br/>
			<?php 
				if(isset($error_Ville)){
					echo '<span class="alerte">'.$error_CP."</span><br/>";
				}

			?>

			<input type="text" name="Ville" placeholder="Ville" value="<?php if(isset($Ville)) echo $Ville ?>" maxlength="5" required="required">
		</label><br/>
		<label>
			<span>Date_Embauche</span><br/>
			<?php 
				if(isset($error_date)){
					echo '<span class="alerte">'.$error_date."</span><br/>";
				}

			?>

			<input type="date" name="Date_Embauche" value="<?php if(isset($Date_Embauche)) echo $Date_Embauche ?>" required="required">
		</label><br/>

		<label>
			<span>Code Secteur</span><br>
			<select name="Code_Secteur">
			<?php

				$sec = $DB->query('Select * from secteur',array());
				 

			foreach ($sec as $r) {

				echo '<option value='.$r["SEC_CODE"].' >'.$r["SEC_CODE"]."  ".$r['SEC_LIBELLE'].'</option>';
			} 

			?>

	  		</select>

  		</label><br/>

  			<label>
			<span>Code Departement</span><br>
			<select name="Code_dep">
					<?php

						$sec = $DB->query('Select * from departement',array());
						 

					foreach ($sec as $r) {

						echo "<option value=".$r["DEP_CODE"]." >".$r["DEP_CODE"]."  ".$r["DEP_NOM"]."</option>";
					} 

					?>

	  		</select>
  		</label><br/>

		<button id="inscription_button" name="Inscription">Inscription</button>


	</form>

</body>
</html>