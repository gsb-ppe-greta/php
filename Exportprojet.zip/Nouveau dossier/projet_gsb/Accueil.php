<?php
include_once ('includes.php');
?>

<link rel="stylesheet" type="text/css" href="./style.css">

<!DOCTYPE html>
<html lang="fr">
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>GSB</title>
</head>
<body>

	<h1 class="accueil-h1">Application Consultation GSB</h1>

<div class="accueil_contenaire">
	<p> 
		Bienvenue sur l'outil de consultation GSB , ici vous retrouverez la liste des médecins recensés.
	</p>

	<div class="accueil_choix">
			<a id="accueil_connexion"  href="./Connexion.php">Connexion</a>
			<a id="accueil_Inscription" href="./inscription.php">Inscription</a>
	</div>
</div>
	
</body>
</html>