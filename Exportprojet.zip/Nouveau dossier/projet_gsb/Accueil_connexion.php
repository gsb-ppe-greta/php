<?php
session_start();
include_once ('includes.php');


 ?>


<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./style.css">
	<title>Accueil_connexion</title>
</head>
<body>

<h1 class="accueil-h1">Consultation</h1>
    
	<p> <?php

    	if(!isset($_SESSION['id'])){
    		echo "vous n'etes pas connecté";
    	header('Location: Connexion.php');
    exit;
  }
    	 ?>

 	</p>
 	
 	<!-- <a href="Parametres.php">Parametres du compte</a> -->

	 <!-- <a href="deconnexion.php">Deconnexion</a> -->


     
   <form method="POST" action="Accueil_connexion.php">

    <input type="text" name="Search" placeholder="Rechercher..">

       <select name="CodePostal">
        <option></option>
        <option>35</option> 
        <option>22</option>
         
       </select>

    <button>Rechercher</button>
   </form> 

<?php
if(!empty($_POST)){
    extract($_POST);

$Specialite=htmlspecialchars(trim($Search));


        $req = $DB->query('Select * from praticien ',array());
    

  echo '<table width="70%" border="1" cellpadding="5" cellspacing="5">
          <tr>
              <th>Nom</th>
              <th>Specialite</th>
              <th>Ville</th>
              <th>Adresse</th>
              <th>CP</th>
              <th>Telephone</th>
          </tr>';

foreach ($req as $r) {
  echo '<tr>
                <td>'.$r["Nom"].'</td>
                <td>'.$r["Specialite"].'</td>
                <td>'.$r["Ville"].'</td>
                <td>'.$r["Adresse"].'</td>
                <td>'.$r["CP"].'</td>
                <td>'.$r["Telephone"].'</td>
      </tr>';
  # code...
}

echo '</table>';
  
}
  ?>


</body>
</html>