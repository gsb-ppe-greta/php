<?php 
session_start();



include_once('includes.php');


//Si connecter , plus possible de retourner sur la page connexion.php

if(isset($_SESSION['id'])){
header('Location: Accueil_connexion.php');
		exit;
}

if(!empty($_POST)){
	extract($_POST);
	$valid = true;

	$Identifiant = htmlspecialchars(trim($Identifiant)); //Pas de caractères spéciaux ni espace
	$mdp = htmlspecialchars(trim($mdp));

	if(empty($Identifiant)){ 
		$valid = false;
		$error_pseudo = "Veuillez renseigner un identifiant";
	}

	if(empty($mdp)){
		$valid = false;
		$error_mdp = "Veuillez renseigner un mot de passe";
	}

	//charge les informations correspondant au pseudo et mdp entré
	$req = $DB->query('Select * from user where Identifiant= :Identifiant and Motdepasse= :Motdepasse ',array('Identifiant' => $Identifiant, 'Motdepasse'=>md5($mdp)));
	$req = $req->fetch();

	if(!$req['Identifiant']){
		$valid =fasle;
		$error_compt = "Votre pseudo ou mot de passe ne correspondent pas";

	}

	if($valid){

		$_SESSION['id'] = $req['id'];
		$_SESSION['Identifiant'] = $req['Identifiant'];

		header('Location:Accueil_connexion.php');
		exit;

	}




}


?>
<!DOCTYPE html>
<html>
<head>
	<title>Connexion</title>
	<link rel="stylesheet" type="text/css" href="./style.css">
</head>
<body>

	<form class="connexion_form" method="post" action="Connexion.php">
			<label>
			<span>Identifiant</span><br/>
			<?php 
				if(isset($error_pseudo)){
					echo $error_pseudo."<br/>";
				}

			?>

			<input type="text" name="Identifiant" placeholder="Identifiant" value="<?php if(isset($Identifiant)) echo $Identifiant ?>" maxlength="20" required="required">
			</label><br/>

			<label>
				<span>Mot de passe</span><br/>
				<?php 
					if(isset($error_mdp)){
						echo $error_mdp."<br/>";
					}

				?>
				<input type="password" name="mdp" placeholder="Mot de passe" value="<?php if(isset($mdp)) echo $mdp ?>" maxlength="20" required="required">
			</label><br/>
			<button id="connexion_bouton" name="Connexion">Connexion</button>


	</form>

</body>
</html>