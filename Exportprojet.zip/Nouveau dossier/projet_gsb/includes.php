<?php
include_once 'connexionBD.php';
$DB = new connexionDB();

?>