<?php
session_start();

include_once ('includes.php');


//Si connecter , plus possible de retourner sur la page inscription.php
if(isset($_SESSION['id'])){
		header('Location: Accueil_connexion.php');
		exit;
}

if (!empty($_POST)){
	extract($_POST);
	$valid = true;



	$Identifiant = htmlspecialchars(trim($Identifiant)); //Pas de caractères spéciaux ni espace
	$mail = htmlspecialchars(trim($mail));
	$mdp = htmlspecialchars(trim($mdp));
	$ConfirmerMdp= htmlspecialchars(trim($ConfirmerMdp));



	if(empty($Identifiant)){ 
		$valid = false;
		$error_pseudo = "Veuillez renseigner un identifiant";
	}
	//verification si l'identifiant est déja use
	$req = $DB->query('Select Identifiant from user where identifiant= :Identifiant', array('Identifiant' => $Identifiant));
	$req = $req->fetch();

	if (!empty($Identifiant) && $req['Identifiant']){
		$valid =false;
		$error_pseudo = "Cet identifiant est déja pris";
	}

	if(empty($mail)){
		$valid = false;
		$error_mail = "Veuillez renseigner un mail";
	}
	    if (!preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", $_POST['mail']))
    {
        echo 'L\'adresse ' . $_POST['mail'] . ' est <strong>invalide</strong> !';
    }

	if(empty($mdp)){
		$valid = false;
		$error_mdp = "Veuillez renseigner un mot de passe";
	}

	if(empty($ConfirmerMdp)){
		$valid = false;
		$error_confirmemdp = "Veuillez confirmer le mot de passe";
	}

	if(!empty($mdp) && !empty($ConfirmerMdp)){
		if($mdp != $ConfirmerMdp){
			$valid= false;
			$error_confirmemdp = "La confirmation est différente";


		}
	}

	if($valid){
		$DB->insert('Insert into user (Identifiant,AdresseMail,Motdepasse) values (:Identifiant, :AdresseMail, :Motdepasse)', array ('Identifiant' => $Identifiant, 'AdresseMail' => $mail, 'Motdepasse' => md5($mdp)));
		header('Location: Connexion.php');
		exit;

	}

}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="./style.css">
	<title>Inscription</title>
</head>
<body>
	<h1 id="inscription_titre">Inscription</h1>
	<form class="inscription_form" method="post" action="inscription.php">
		<label>
			<span>Identifiant</span><br/>
			<?php 
				if(isset($error_pseudo)){
					echo '<span class="alerte">'.$error_pseudo."</span><br/>";
				}

			?>

			<input type="text" name="Identifiant" placeholder="Identifiant" value="<?php if(isset($Identifiant)) echo $Identifiant ?>" maxlength="20" required="required">
		</label><br/>
		<label>
			<span>Adresse Mail</span><br/>
			<?php 
				if(isset($error_mail)){
					echo $error_mail."<br/>";
				}

			?>
			<input type="Mail" name="mail" placeholder="xxxxx@xxxxx.xxx" value="<?php if(isset($mail)) echo $mail ?>" maxlength="20" required="required">
		</label><br/>
		<label>
			<span>Mot de passe</span><br/>
			<?php 
				if(isset($error_mdp)){
					echo $error_mdp."<br/>";
				}

			?>
			<input type="password" name="mdp" placeholder="Mot de passe" value="<?php if(isset($mdp)) echo $mdp ?>" maxlength="20" required="required">
		</label><br/>

		<label>
			<span>Confirmer le Mdp</span><br/>
			<?php 
				if(isset($error_confirmemdp)){
					echo $error_confirmemdp."<br/>";
				}

			?>
			<input type="password" name="ConfirmerMdp" placeholder="Mot de passe" value="<?php if(isset($ConfirmerMdp)) echo $ConfirmerMdp ?>" maxlength="20" required="required">
		</label><br/>

		<button id="inscription_button" name="Inscription">Inscription</button>


	</form>

</body>
</html>