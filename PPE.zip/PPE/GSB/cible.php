<?php




// On commence par récupérer les champs 
if(isset($_POST['nom']))                   $nom=$_POST['nom'];
else      $nom="";

if(isset($_POST['prenom']))                $prenom=$_POST['prenom'];
else      $prenom="";

if(isset($_POST['adresse']))               $adresse=$_POST['adresse'];
else      $adresse="";

if(isset($_POST['ville']))                 $ville=$_POST['ville'];
else      $ville="";

if(isset($_POST['codePostal']))            $codePostal=$_POST['codePostal'];
else      $codePostal="";

if(isset($_POST['telephone']))             $telephone=$_POST['telephone'];
else      $telephone="";

if(isset($_POST['specialite']))            $specialite=$_POST['specialite'];
else      $specialite="";

if(isset($_POST['descriptifMedecin']))      $descrptifMedecin=$_POST['descriptifMedecin'];
else      $descrptifMedecin="";

if(isset($_POST['departement']))           $departement=$_POST['departement'];
else      $departement="";

// On vérifie si les champs sont vides 
if(empty($nom) OR empty($prenom) OR empty($adresse) OR empty($ville) OR empty($codePostal) OR empty($telephone) OR empty($specialite) OR empty($descrptifMedecin)  OR empty($departement)) 
    { 
    echo '<font color="red">Attention, seul le champs <b>ICQ</b> peut rester vide !</font>'; 
    } 

// Aucun champ n'est vide, on peut enregistrer dans la table 
else      
    { 
       // connexion à la base
   $db = new PDO('mysql:host=localhost;port=3306;dbname=gsbppe', 'root', '')  or die('Erreur de connexion '.mysql_error());
   
// sélection de la base  

   

    // on écrit la requête sql 
 
     
    // on insère les informations du formulaire dans la table 

  
    echo 'Vos infos on été ajoutées.';                     // on affiche le résultat pour le visiteur

     $db = null; // on ferme la connexion  mysql_close();
    }  
?>