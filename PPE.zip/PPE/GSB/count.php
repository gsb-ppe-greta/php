<?php
require 'db.php';
session_start();
?>


<?php
 $conn = mysqli_connect("localhost", "root", "", "gsbppe");
    // Check connection
    if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
         

     $result = mysqli_query($conn, "SELECT COUNT(*) AS `count` FROM `praticien`");
     $row = mysqli_fetch_array($result);
     $count = $row['count'];
     echo'$count';

   } 
   
   else { echo "0 results"; }

  $conn->close();
   ?>