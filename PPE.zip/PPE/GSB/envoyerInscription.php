<?php
if(isset($_POST["submit"])){
$hostname='localhost';
$username='root';
$password='';
 
try {
$dbh = new PDO("mysql:host=$hostname;dbname=gsbppe",$username,$password);
 
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // <== add this line

$sql = "INSERT INTO users (email, password )

VALUES ('".$_POST["email"]."', '".$_POST["password"]."')";

if ($dbh->query($sql)) {
    
    echo 'ajout réussit';
}

else{
echo "<script type= 'text/javascript'>alert('Data not successfully Inserted.');</script>";
}
 
$dbh = null;
}
catch(PDOException $e)
{
echo $e->getMessage();
}
 
}
?>