<?php
if ($adresse=null) {
    echo'Vrai';
    # code...
} else {
    echo 'Faux';
}



?>