<?php
require 'db.php';
session_start();
?>


<?php
if(isset($_POST['submit']))

{


$email  = htmlentities(trim($_POST['email']));   
$password = htmlentities(trim($_POST['password']));
$repeatpassword =  htmlentities(trim($_POST['repeatpassword']));

 if($_emaiil&&$password&&$repeatpassword) 
 {


  if($password==$repeatpassword) {

   $connect = mysql_connect('localhost','root','') or die ('Error');

   mysql_select_db('gsbppe');

   $query = mysql_query(" INSERT INTO 'users' ('id', 'email', 'password') VALUES ('', 'ndiayeibrahim666@gmail.com', '123456')");
      
  } else echo " les deux mots de passent ne se ressemblent pas";

 } else echo"veuillez saisir tous les champs";

}

?>