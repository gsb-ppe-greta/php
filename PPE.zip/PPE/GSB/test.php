<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <script src="main.js"></script>
</head>
<body>
    <table>
        <tr>
            <th>Numéro Praticien</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Ville</th>
            <th>Code Postal</th>
        </tr>
        <?php
        $conn = mysqli_connect("localhost", "root","","gsbppe");
        if ($conn-> connect_error) {
            die("Connection failed:". $conn-> connect_error);

            $sql = "SELECT * FROM praticien";
            $result = $conn-> query($sql);

            if ($result -> num_rows > 0) {
               while ($row = $result-> fetch_assoc()) {
                   echo "<tr><td>" . $row["PRA_NUM"] ."</td><td>". $row["PRA_NOM"] ."</td><td>". $row["PRA_PRENOM"] ."</td></tr>";
                   # code...
               }
               echo"</table>";
            }
            else {
                echo "0 result";
            }

            $conn-> close();
            }

        ?>
    </table>
</body>
</html>