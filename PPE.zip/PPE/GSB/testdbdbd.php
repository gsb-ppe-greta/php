<?php
    //connection au serveur:
    $cnx = mysql_connect( "localhost", "root", "" ) ;
 
    //sélection de la base de données:
    $db = mysql_select_db( "greg" ) ;
 
 
$nom=""; 
if(!empty($_POST["nom"]))
   $nom=$_POST["nom"];
 
$prenom=""; 
if(!empty($_POST["prenom"]))
   $prenom=$_POST["prenom"];
 
 
$jour=""; 
if(!empty($_POST["jour"]))
   $adresse=$_POST["jour"];
 
$mois=""; 
if(!empty($_POST["mois"]))
   $code_postal=$_POST["mois"];
 
$annee=""; 
if(!empty($_POST["annee"]))
   $ville=$_POST["annee"];
 
$heure=""; 
if(!empty($_POST["heure"]))
   $num_tel=$_POST["heure"];
 
$minute=""; 
if(!empty($_POST["minute"]))
   $email=$_POST["minute"];
 
$evenement=""; 
if(!empty($_POST["evenement"]))
   $email=$_POST["evenement"];
 
 
// Ajoute la nouvelle fiche
$sql = "INSERT INTO agenda (id,  nom, prenom, jour, mois, annee, heure, minute, contenu)
          VALUES ('','$nom','$prenom','$jour','$mois','$annee','$heure','$minute','$evenement')"; 
 
 
//exécution de la requête SQL:
  $requete = mysql_query($sql, $cnx) or die( mysql_error() ) ;
 
  //affichage des résultats, pour savoir si l'insertion a marchée:
  if($requete)
  {
    echo "<div class=\"kuku\">L'insertion a été correctement effectuée</div>" ;
  }
  else
  {
    echo "<div class=\"kuku\">L'insertion à échouée</div>" ;
  }
$cnx= mysql_close();
 
?>